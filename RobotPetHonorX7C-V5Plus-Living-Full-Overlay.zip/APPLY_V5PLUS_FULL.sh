#!/usr/bin/env bash
set -euo pipefail

# Remove later-version-only source that must not remain beside the V5+ tree.
rm -f \
  app/src/main/java/com/shehan/robotpet/brain/BehaviorExecutive.kt \
  app/src/main/java/com/shehan/robotpet/brain/EventGate.kt \
  app/src/main/java/com/shehan/robotpet/voice/WakeWordManager.kt \
  app/src/main/java/com/shehan/robotpet/voice/WakeWordMatcher.kt \
  app/src/test/java/com/shehan/robotpet/brain/BehaviorExecutiveTest.kt \
  app/src/test/java/com/shehan/robotpet/brain/EventGateTest.kt \
  app/src/test/java/com/shehan/robotpet/voice/WakeWordMatcherTest.kt

echo "V5+ full overlay cleanup complete."
